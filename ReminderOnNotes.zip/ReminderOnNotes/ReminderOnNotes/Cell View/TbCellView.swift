//
//  TbCellView.swift
//  ReminderOnNotes
//
//  Created by Pawan iOS on 22/11/2022.
//

import UIKit

class TbCellView: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }
    
}
