//
//  ViewController.swift
//  ReminderOnNotes
//
//  Created by Pawan iOS on 22/11/2022.
//

import UIKit
import UserNotifications

struct MyReminder {
    let title: String
    let date : Date
    let identifier : String
}

class ViewController: UIViewController {

    @IBOutlet weak var tbView: UITableView!
    var models = [MyReminder]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func didTapAdd() {
        let addViewController = AddViewController()
        addViewController.title = "Add New Reminder"
        addViewController.completion = { title, body, date in
            DispatchQueue.main.async {
                self.navigationController?.popToRootViewController(animated: true)
                let new = MyReminder(title: title, date: date, identifier:  "id_\(title)")
                self.models.append(new)
                self.tbView.reloadData()
                
                
                UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .badge, .sound]) { success, error in
                    if success {
                        let content = UNMutableNotificationContent()
                        content.title = title
                        content.sound = .default
                        content.body  = body
                        
                        let targetDate = date
                        let triger = UNCalendarNotificationTrigger(dateMatching: Calendar.current.dateComponents([.year, .month, .day, .hour, .minute, .second], from: targetDate ), repeats: false)
                        
                        let request = UNNotificationRequest(identifier: "some_Long_id", content: content, trigger: triger )
                        
                        UNUserNotificationCenter.current().add(request) { error in
                            if error != nil {
                                print("Something wrong")
                            }
                        }
                    } else if error != nil {
                        print("Error")
                    }
                }
            }
        }
        navigationController?.pushViewController(addViewController, animated: true)
    }
}

extension ViewController: UITableViewDataSource, UITableViewDelegate {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return models.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell =  ReminderTbViewCell.registerTableViewCell(tableView: tableView)
        cell.title.text = models[indexPath.row].title
        
        let date = models[indexPath.row].date
        let formatter = DateFormatter()
        formatter.dateFormat = "MMM, dd, YYYY"
        cell.dateLbl.text = formatter.string(from: date)
    
        return cell
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 80
    }
}
