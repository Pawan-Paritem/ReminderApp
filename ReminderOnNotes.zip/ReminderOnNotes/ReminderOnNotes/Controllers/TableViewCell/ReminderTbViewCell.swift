//
//  ReminderTbViewCell.swift
//  ReminderOnNotes
//
//  Created by Pawan iOS on 22/11/2022.
//

import UIKit

class ReminderTbViewCell: UITableViewCell {

    @IBOutlet weak var dateLbl: UILabel!
    @IBOutlet weak var title: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }
    
    class func registerTableViewCell( tableView: UITableView) -> ReminderTbViewCell {
        let identifer = "cell"
        tableView.register(UINib(nibName: "ReminderTbViewCell", bundle: Bundle.main), forCellReuseIdentifier: identifer)
        
        let cell = tableView.dequeueReusableCell(withIdentifier: identifer) as! ReminderTbViewCell
        
        return cell
    }
}
