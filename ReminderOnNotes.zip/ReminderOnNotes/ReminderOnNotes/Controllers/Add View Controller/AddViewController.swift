//
//  AddViewController.swift
//  ReminderOnNotes
//
//  Created by Pawan iOS on 22/11/2022.
//

import UIKit

class AddViewController: UIViewController {

    @IBOutlet weak var titleTextField: UITextField!    
    @IBOutlet weak var dateTimePicker: UIDatePicker!
    @IBOutlet weak var textView: UITextView!
    
    public var completion:  ((String, String, Date) -> Void)?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Save", style: .done, target: self , action: #selector(didTapSaveButton))
    }
    
    @objc func didTapSaveButton() {
        if let titleText = titleTextField.text, !titleText.isEmpty,
           let bodyText = textView.text, !bodyText.isEmpty {
           let targetDate = dateTimePicker.date
            
            completion?(titleText, bodyText, targetDate )
        }
    }
}
